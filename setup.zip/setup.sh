#!/bin/bash
echo "=== Studentų programa v1.5 diegimas ==="

sudo dpkg -i studentu-programa_1.5-1_amd64.deb

sudo mkdir -p /usr/local/bin/VU/Rokas-Tverijonas/
sudo cp studentai10000.txt /usr/local/bin/VU/Rokas-Tverijonas/
sudo cp studentai100000.txt /usr/local/bin/VU/Rokas-Tverijonas/
sudo cp programa1 /usr/local/bin/VU/Rokas-Tverijonas/

cat > ~/Desktop/studentai.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Studentų programa (Rokas Tverijonas)
Exec=sudo /usr/local/bin/VU/Rokas-Tverijonas/programa1
Terminal=true
Categories=Education;
EOF
chmod +x ~/Desktop/studentai.desktop

sudo mkdir -p ~/.local/share/applications/VU/
cat > ~/.local/share/applications/VU/studentai.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Studentų programa (Rokas Tverijonas)
Exec=sudo /usr/local/bin/VU/Rokas-Tverijonas/programa1
Terminal=true
Categories=Education;
EOF

echo "=== Diegimas baigtas! ==="
echo "Programa įdiegta į: /usr/local/bin/VU/Rokas-Tverijonas/"
echo "Darbalaukio nuoroda sukurta!"
echo "Programų meniu nuoroda sukurta!"
